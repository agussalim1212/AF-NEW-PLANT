﻿namespace SkeletonApi.Presentation
{
    public static class AssemblyReference
    {

    }
}