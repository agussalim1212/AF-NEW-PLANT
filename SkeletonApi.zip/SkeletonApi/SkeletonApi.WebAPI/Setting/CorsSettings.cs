﻿namespace SkeletonApi.WebAPI.Setting
{
    public class CorsSettings
    {
        public string[] AllowedHosts { get; set; }
    }
}
