﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SkeletonApi.Infrastructure.Common
{
    public class MqttBrokerSettings
    {
        public string Host { get; set; }
        public int Port { get; set; }
    }
}
